$(document).ready(function() {
	
	// enable fileuploader plugin
	$('input[name="files"]').fileuploader({
		addMore: true,
        inputNameBrackets: false
    });
	
});